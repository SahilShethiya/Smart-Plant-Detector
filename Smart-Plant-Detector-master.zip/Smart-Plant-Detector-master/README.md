# PlantDiseaseDetection

It is a plant disease detection project...
cnn.py is used to train and test the model
ui.py is used for finding the disease in the given leaf by the user

PACKAGE REQUIREMENTS
  numpy (pip install numpy)
  tqdm (pip install tqdm)
  TensorFlow
  openCv
  matplotlib
